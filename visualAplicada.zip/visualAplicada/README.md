# visualAplicada

To create project: dotnet new console -o name_of_project</br>
To run project: dotnet run</br>
